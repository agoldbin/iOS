//
//  DataPackage.swift
//  Protocols
//
//  Created by Aaron Goldbin on 11/4/18.
//

import Foundation

protocol dataPackage {
    var receivedName: String? {get set}
}
